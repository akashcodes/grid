from . import Modules
from Modules.tags.interest import get_interest