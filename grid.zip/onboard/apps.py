from django.apps import AppConfig


class OnboardConfig(AppConfig):
    name = 'onboard'
